## DiaGioiHanhCHinhVN
 Script tự động tải file excel từ website tổng cục thống kê https://danhmuchanhchinh.gso.gov.vn/ và chuyển sang dạng cây json.

  - Tỉnh
    + Id
    + Name
    + Districts
        + Id
        + Name
        + Wards
          + Id
          + Name
          + Level (Cấp hành chính phường,xã,thị trấn)
    